## Copyright (c) Microsoft Corporation.
## Licensed under the MIT license.


<#
.SYNOPSIS
    SQL LogScout allows you to collect diagnostic logs from your SQL Server system to help resolve technical problems.
.DESCRIPTION
.LINK 
https://github.com/microsoft/SQL_LogScout#examples

.EXAMPLE
   SQL_LogScout.ps1
.EXAMPLE
    SQL_LogScout.ps1 -Scenario GeneralPerf
.EXAMPLE
    SQL_LogScout.ps1 -Scenario DetailedPerf -ServerName "SQLInstanceName" -CustomOutputPath "UsePresentDir" -DeleteExistingOrCreateNew "DeleteDefaultFolder"
.EXAMPLE
    SQL_LogScout.ps1 -Scenario "AlwaysOn" -ServerName "DbSrv" -CustomOutputPath "PromptForCustomDir" -DeleteExistingOrCreateNew "NewCustomFolder" -DiagStartTime "2000-01-01 19:26:00" -DiagStopTime "2020-10-29 13:55:00"
.EXAMPLE
   SQL_LogScout.ps1 -Scenario "GeneralPerf+AlwaysOn+BackupRestore" -ServerName "DbSrv" -CustomOutputPath "d:\log" -DeleteExistingOrCreateNew "DeleteDefaultFolder" -DiagStartTime "01-01-2000" -DiagStopTime "04-01-2021 17:00" -InteractivePrompts "Quiet"
#>


#=======================================Script parameters =====================================
param
(
    # DebugLevel parameter is deprecated
    # SQL LogScout will generate *_DEBUG.LOG with verbose level 5 logging for all executions
    # to enable debug messages in console, modify $global:DEBUG_LEVEL in LoggingFacility.ps1
    
    #help parameter is optional parameter used to print the detailed help "/?, ? also work"
    [Parameter(ParameterSetName = 'help',Mandatory=$false)]
    [Parameter(Position=0)]
    [switch] $help,

    #Scenario an optional parameter that tells SQL LogScout what data to collect
    [Parameter(Position=1,HelpMessage='Choose a plus-sign separated list of one or more of: Basic,GeneralPerf,DetailedPerf,Replication,AlwaysOn,Memory,DumpMemory,WPR,Setup,NoBasic. Or MenuChoice')]
    [string[]] $Scenario=[String]::Empty,

    #servername\instnacename is an optional parameter since there is code that auto-discovers instances
    [Parameter(Position=2)]
    [string] $ServerName = [String]::Empty,

    #Optional parameter to use current directory or specify a different drive and path 
    [Parameter(Position=3,HelpMessage='Specify a valid path for your output folder, or type "UsePresentDir"')]
    [string] $CustomOutputPath = "PromptForCustomDir",

    #scenario is an optional parameter since there is a menu that covers for it if not present
    [Parameter(Position=4,HelpMessage='Choose DeleteDefaultFolder|NewCustomFolder')]
    [string] $DeleteExistingOrCreateNew = [String]::Empty,

    #specify start time for diagnostic
    [Parameter(Position=5,HelpMessage='Format is: "2020-10-27 19:26:00"')]
    [string] $DiagStartTime = "0000",
    
    #specify end time for diagnostic
    [Parameter(Position=6,HelpMessage='Format is: "2020-10-27 19:26:00"')]
    [string] $DiagStopTime = "0000",

    #specify quiet mode for any Y/N prompts
    [Parameter(Position=7,HelpMessage='Choose Quiet|Noisy')]
    [string] $InteractivePrompts = "Noisy",

    [Parameter(Position=8,HelpMessage='Provide 0 for no repetition | Specify >0 for as many times as you want to run the script. Default is 0.')]
    [int] $RepeatCollections = 0
    
)

function Test-PowerShellVersionAndHost()
{
    #check for version 4-6 and not ISE 
    $psversion_maj = (Get-Host).Version.Major
    $psversion_min = (Get-Host).Version.Minor
    $pshost_name = (Get-Host).Name

    if (($psversion_maj -lt 4) -or ($psversion_maj -ge 7))
    {
        Microsoft.PowerShell.Utility\Write-Host "Please use a supported PowerShell version 4.x, 5.x or 6.x. Your current verion is $psversion_maj.$psversion_min." -ForegroundColor Yellow
        Microsoft.PowerShell.Utility\Write-Host "Exiting..." -ForegroundColor Yellow
        exit 7654321
    }
    elseif ($pshost_name -match "ISE") 
    {
        Microsoft.PowerShell.Utility\Write-Host "The 'Windows PowerShell ISE Host' is not supported as a PowerShell host for SQL LogScout." -ForegroundColor Yellow
        Microsoft.PowerShell.Utility\Write-Host "Please use a PowerShell console (ConsoleHost)"  -ForegroundColor Yellow
        Microsoft.PowerShell.Utility\Write-Host "Exiting..." -ForegroundColor Yellow
        exit 8765432
    }

    else {
        Write-Host "Launching SQL LogScout..."
    }
}


# get the full but by default short path of the temp folder and convert it to full path. Then store it in a global variable
$shortEnvTempPath = $env:TEMP
$global:EnvTempVarFullPath = (Get-Item $shortEnvTempPath).FullName

# create a temporary log file to store the output of the repeated executions
# the file will be created in the temp folder and will be deleted at the end of the script

$script:temp_output_sqllogscout = $global:EnvTempVarFullPath + "\SQL_LogScout_Repeated_Execution_" + (Get-Date).ToString('yyyyMMddhhmmss') + ".txt"
$script:search_pattern = $global:EnvTempVarFullPath+ "\SQL_LogScout_Repeated_Execution_*.txt"

function Write-SQLLogScoutTempLog()
{
    param 
    ( 
        [Parameter(Position=0,Mandatory=$true)]
        [Object]$Message
    )

    try
    {        
        [String]$strMessage = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
        $strMessage += "	: "
        $strMessage += [string]($Message)

        Add-Content -Path $script:temp_output_sqllogscout -Value $strMessage
    }
	catch
	{
		Write-Host "Exception writing to the temp log file: $script:temp_output_sqllogscout. Error: $($_.Exception.Message)"
	}
    
}


# the main script
try 
{
    # validate the minimum version of PowerShell and PowerShell host (not ISE)
    Test-PowerShellVersionAndHost

    # check if the temp log file exists, if it does, then delete it
    if (Test-Path -Path $script:search_pattern)
    {
        Remove-Item -Path $script:search_pattern -Force
    }

    # set the output folders array to store all the folders which are created by SQL LogScout in repeated mode
    $script:output_folders_multiple_runs = @()

    # set the execution counter to 0
    [int] $execution_counter = 0

    # If the user wants to run the main script multiple times, then we will loop through multiple times with max = RepeatCollections
    # if RepeatCollections is set to 0, then we will run the script only once (we don't want to repeat)

    do
    {

        # changes the directory to the location of the script, which is the root of SQL LogScout and stores on the stack
        Push-Location -Path $PSScriptRoot

        # Change the location to the Bin folder, 
        Set-Location .\Bin\

        
        # enforce repeat collection to be a valid number (0 or greater)
        if ([Int]::TryParse($RepeatCollections, [ref]$null) -eq $false)
        {
            Microsoft.PowerShell.Utility\Write-Host "Please provide a valid number value for the RepeatCollections parameter (0 or greater)" -ForegroundColor Yellow
            break
        }
        else 
        {
            if (($RepeatCollections -lt 0) -or ($RepeatCollections -eq $null))
            {
                $RepeatCollections = 0
            }
        }

        if ($execution_counter -eq 0)
        {
            Write-SQLLogScoutTempLog "Initial collection running."
            Write-SQLLogScoutTempLog "Total Repeat collections: $RepeatCollections. This count is in addition to the initial collection. Thus the total LogScout collections will be $($RepeatCollections + 1)."
        }
        else 
        {
            Write-SQLLogScoutTempLog "Repeat collection running. Current iteration count: $execution_counter"
        }

        
        # if the user wants multiple executions of the script, then we need to set some parameters 
        if (($RepeatCollections -gt 0))
        {
            
        
            #if repeat collection is set to > 0, then we need to make sure the user has passed a custom output path value or use current path
            if ($CustomOutputPath -eq "PromptForCustomDir")
            {
                Microsoft.PowerShell.Utility\Write-Host "The default value 'PromptForCustomDir' for the CustomOutputPath parameter isn't a valid option when used with RepeatCollections. Specify 'UsePresentDir' or a valid path." -ForegroundColor Yellow
                break
            }

            #if repeat collection is set to > 0, then interactive prompts should be set to quiet
            $InteractivePrompts = "Quiet"


            #if repeat collection is set to > 0, then we need to make sure DeleteExistingOrCreateNew is not null or empty
            #if $DeleteExistingOrCreateNew isn't "DeleteDefaultFolder", "NewCustomFolder", then main script will validate that
            if([Int]::TryParse($DeleteExistingOrCreateNew, [ref]$null) -eq $true)
            {
                #convert the string to an integer and store it in the folders_to_preserve variable
                #this will be used to preserve the most recent folders and delete the rest
                $folders_to_preserve = [Int]::Parse($DeleteExistingOrCreateNew)

                Write-SQLLogScoutTempLog "Folders to keep was set to $folders_to_preserve by the user." 

                #if the value is a number, it behaves like a new custom folder to be created
                $DeleteExistingOrCreateNew = "NewCustomFolder"
            }
            elseif($DeleteExistingOrCreateNew -notin "DeleteDefaultFolder","NewCustomFolder")
            {
                #if the value is "DeleteDefaultFolder", then we will delete the default folder
                Microsoft.PowerShell.Utility\Write-Host "To run in continous mode (RepeatCollections), please provide a valid 'DeleteExistingOrCreateNew' value." -ForegroundColor Yellow
                break
            }

            # If repeat collection is set to > 0, then we need to make sure the user has passed all the parameters for time range
            if ($DiagStartTime -eq "0000" -or $DiagStopTime -eq "0000")
            {
                Microsoft.PowerShell.Utility\Write-Host "Please provide a valid start time (DiagStartTime) and stop time (DiagStopTime) parameters." -ForegroundColor Yellow
                break
            }
        

            #if repeat collection is set to > 0, then we need to make sure the user has passed a server name and scenario
            if (($true -eq [String]::IsNullOrWhiteSpace($ServerName)) -or ($true -eq [String]::IsNullOrWhiteSpace($Scenario)))
            {
                Microsoft.PowerShell.Utility\Write-Host "Please provide a valid server name and scenario for the diagnostic" -ForegroundColor Yellow
                break
            }
        }
        else 
        {
            #if the user has not provided a value for RepeatCollections, then DeleteExistingOrCreateNew should not be a number
            if([Int]::TryParse($DeleteExistingOrCreateNew, [ref]$null) -eq $true)
            {
                Microsoft.PowerShell.Utility\Write-Host "The 'DeleteExistingOrCreateNew' parameter cannot be a number if the 'RepeatCollections' parameter is less than 1. If you want to use repeated collections, specify a value of 1 or greater for RepeatCollections." -ForegroundColor Yellow
                break
            }
            
            
        }

        #create an object to keep track of how many times SQL LogScout will be executed if continuous mode/repeat collection is selected
        #if the user wants to delete the default folder, then we will set the folder overwrite to true
        $ExecutionCountObj = [PSCustomObject]@{
            CurrentExecCount = $execution_counter
            RepeatCollection= $RepeatCollections
            OverwriteFolder = $null}
        
        
        #if user needs to show help, do this
        if ($help)
        {
            .\SQLLogScoutPs.ps1 -help
        }
        # execute SQL LogScout with the parameters provided
        else 
        {
         
            # If repeat collection is set to > 0, then we will keep running the script until we reach RepeatCollections value or the user presses Ctrl+C
            .\SQLLogScoutPs.ps1 -Scenario $Scenario -ServerName $ServerName -CustomOutputPath $CustomOutputPath -DeleteExistingOrCreateNew $DeleteExistingOrCreateNew `
                                -DiagStartTime $DiagStartTime -DiagStopTime $DiagStopTime -InteractivePrompts $InteractivePrompts `
                                -ExecutionCountObject $ExecutionCountObj 
        }


        
        # Add the latest output folder used by LogScout to the array if in repeat mode and reset the global output folder variable
        if ($RepeatCollections -gt 0)
        {

            #if the user has not provided a value for folders to preserve, then we will preserve all the output folders
            # also this value can be reset to null later if the user has provided a number greater than the repeat collections
            if ($null -eq $folders_to_preserve)
            {
                Write-SQLLogScoutTempLog "Folders_to_Preserve is null. Will preserve all output folders."

            }
            
            #reset/correct the number of folders to preserve. 
            #if the user has provided a number, then we will use that number to preserve the folders
            #if the user has provided a number greater than the repeat collections, we won't delete any folders, just keep the ones created
            #if folders to keep is set to 0 folders, then we will default to 1
            if ($folders_to_preserve -eq 0)
            {
                $folders_to_preserve = 1
                Write-SQLLogScoutTempLog "Folders to keep was reset to: $folders_to_preserve" 
            }
            elseif ($folders_to_preserve -ge $RepeatCollections)
            {
                #set the folders to preserve to null, so we don't delete any folders
                Write-SQLLogScoutTempLog "Folders to keep was reset to 'null' since it's larger than RepeatCollecitons. No folders will be deleted." 
                $folders_to_preserve = $null
            }

            Write-SQLLogScoutTempLog "Folders to keep is set to: $folders_to_preserve" 

            #add the output folder to the array script level variable
            $script:output_folders_multiple_runs += $global:output_folder
            
            #log the output folders 
            Write-SQLLogScoutTempLog ("Output folders: `r`n`t`t`t" + ($script:output_folders_multiple_runs -Join "`r`n`t`t`t"))

            #reset the global output folder variable. use a string instead of a $null for debugging purposes
            $global:output_folder = "invalid_folder_path"

            # Get last write times for each folder using Get-Item
            $folderLastWriteTimes = @{}
            foreach ($folderPath in $script:output_folders_multiple_runs) 
            {
                #add both key and value in hash table if the folder exists
                if (Test-Path -Path $folderPath)
                {
                    $folderLastWriteTimes[$folderPath] = (Get-Item $folderPath).LastWriteTime
                }
            }

            # Preserve the most recent X folders and delete the remaining ones, but only if the value is greater than 0 or non-null
            # If the user has not provided a number, then we will not delete any folders
            if (($null -ne $folders_to_preserve) -or ($folders_to_preserve -gt 0))
            {
                
                # Sort folder paths based on last write time
                $sortedFolderPaths = $folderLastWriteTimes.GetEnumerator() | Sort-Object -Property Value -Descending |Select-Object -Property Value, Key


                # Preserve the most recent X folders and delete the remaining ones
                $deletedFolders = $sortedFolderPaths | Select-Object -Skip $folders_to_preserve

                # Print deleted folders
                foreach ($del_folder in $deletedFolders)
                {
                    Write-SQLLogScoutTempLog "Folder being deleted: $($del_folder.Key)"
                }

                # Clean up: Remove the folders
                $deletedFolders | ForEach-Object { Remove-Item -Path $_.Key -Force -Recurse }
            }
        }

        # Return to the original location
        Pop-Location

        # Increment the execution counter
        $execution_counter++

    } while ($execution_counter -le $RepeatCollections)

}
catch 
{
    Write-Host $PSItem.Exception.Message

    $exception_str = "Exception line # " + $($PSItem.InvocationInfo.ScriptLineNumber) + ", offset" + $($PSItem.InvocationInfo.OffsetInLine) + ", script ='" + $($PSItem.InvocationInfo.ScriptName) +"'"

    #write the exception to the temp log file and console
    Write-Host $exception_str
    Write-SQLLogScoutTempLog -Message $exception_str

}
finally 
{
    Pop-Location
}


# SIG # Begin signature block
# MIIoLgYJKoZIhvcNAQcCoIIoHzCCKBsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB3z2fv7NsbB7gd
# /el1jdHloZvAtPWNe3HmDInvA7TCUqCCDXYwggX0MIID3KADAgECAhMzAAAEBGx0
# Bv9XKydyAAAAAAQEMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjQwOTEyMjAxMTE0WhcNMjUwOTExMjAxMTE0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC0KDfaY50MDqsEGdlIzDHBd6CqIMRQWW9Af1LHDDTuFjfDsvna0nEuDSYJmNyz
# NB10jpbg0lhvkT1AzfX2TLITSXwS8D+mBzGCWMM/wTpciWBV/pbjSazbzoKvRrNo
# DV/u9omOM2Eawyo5JJJdNkM2d8qzkQ0bRuRd4HarmGunSouyb9NY7egWN5E5lUc3
# a2AROzAdHdYpObpCOdeAY2P5XqtJkk79aROpzw16wCjdSn8qMzCBzR7rvH2WVkvF
# HLIxZQET1yhPb6lRmpgBQNnzidHV2Ocxjc8wNiIDzgbDkmlx54QPfw7RwQi8p1fy
# 4byhBrTjv568x8NGv3gwb0RbAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQU8huhNbETDU+ZWllL4DNMPCijEU4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMjkyMzAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjmD9IpQVvfB1QehvpC
# Ge7QeTQkKQ7j3bmDMjwSqFL4ri6ae9IFTdpywn5smmtSIyKYDn3/nHtaEn0X1NBj
# L5oP0BjAy1sqxD+uy35B+V8wv5GrxhMDJP8l2QjLtH/UglSTIhLqyt8bUAqVfyfp
# h4COMRvwwjTvChtCnUXXACuCXYHWalOoc0OU2oGN+mPJIJJxaNQc1sjBsMbGIWv3
# cmgSHkCEmrMv7yaidpePt6V+yPMik+eXw3IfZ5eNOiNgL1rZzgSJfTnvUqiaEQ0X
# dG1HbkDv9fv6CTq6m4Ty3IzLiwGSXYxRIXTxT4TYs5VxHy2uFjFXWVSL0J2ARTYL
# E4Oyl1wXDF1PX4bxg1yDMfKPHcE1Ijic5lx1KdK1SkaEJdto4hd++05J9Bf9TAmi
# u6EK6C9Oe5vRadroJCK26uCUI4zIjL/qG7mswW+qT0CW0gnR9JHkXCWNbo8ccMk1
# sJatmRoSAifbgzaYbUz8+lv+IXy5GFuAmLnNbGjacB3IMGpa+lbFgih57/fIhamq
# 5VhxgaEmn/UjWyr+cPiAFWuTVIpfsOjbEAww75wURNM1Imp9NJKye1O24EspEHmb
# DmqCUcq7NqkOKIG4PVm3hDDED/WQpzJDkvu4FrIbvyTGVU01vKsg4UfcdiZ0fQ+/
# V0hf8yrtq9CkB8iIuk5bBxuPMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg4wghoKAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAQEbHQG/1crJ3IAAAAABAQwDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBOS+T7TP+7RPFNRVt5oAFGw
# zd/7L7JSu8iqoNvASVLMMEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0B
# AQEFAASCAQAyQemdo279OBlnZs2Lmeu03DSG+vrDIRLwkqd+TM/E5y1pL9nvzrHR
# l1bT8UFx9rRLB4Ke6V8nbCqCxYEpc/bUst2xF411/ogiN/Dn/rXWaQK4pogDBjaO
# BD9amXe2AL5j3tOl7e0Lilmh+jqPBiI/3HWg8Z5tXI4Y/Ad/zT8V3JOffE/CODC7
# WL0Zp67cHKOwxubESLh1JZY+InL1pdtVHvA73ZAxS9+Vx8J1exxbynX7JZXj7bV2
# RuV0yBXJKRm1SFL+hjcOCb34Tf2korV+NAbwJWk3gb+n8tkTirixlplgFBS0tIAk
# 6Y1A6YlutJRZoUSp7HcWx/XaCjFELMbUoYIXljCCF5IGCisGAQQBgjcDAwExgheC
# MIIXfgYJKoZIhvcNAQcCoIIXbzCCF2sCAQMxDzANBglghkgBZQMEAgEFADCCAVEG
# CyqGSIb3DQEJEAEEoIIBQASCATwwggE4AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIGZ0YDNeRbxMkzNKIUdE5PEtY0LhSBV/y/k7llMj/+73AgZn+BCJ
# RSIYEjIwMjUwNDE4MTM1NzIzLjUyWjAEgAIB9KCB0aSBzjCByzELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjg5MDAt
# MDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNl
# oIIR7TCCByAwggUIoAMCAQICEzMAAAIOLMsofZUgdWMAAQAAAg4wDQYJKoZIhvcN
# AQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQG
# A1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjUwMTMwMTk0
# MzAzWhcNMjYwNDIyMTk0MzAzWjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9u
# czEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjg5MDAtMDVFMC1EOTQ3MSUwIwYD
# VQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0B
# AQEFAAOCAg8AMIICCgKCAgEArObe4kbV7dIW3qPTBO/GWIyKN7GkLljARUO1+LPb
# 6KGEQAUzn9qaEx2rcfhMJwVBgdVdrfxOjMLEDZmOV6TP++Wgq2XcQJ61faOE7ubA
# XqW233obKzlkQSBqCROj7VqHdQqxXoZtXYs942Nx/Iha4e56nn54mdUp23FjzMjS
# Mbhhc6UIgwPhOWEt95njKml8IXW9NQpbspof9xCr5J4+HSKUGRFjjzN48W0VQGDe
# SdrTq2JCXHQ8dJdNlfzWHdapL1AYD8ayr4quZM+xOgGzonwg0jAYHJ/1+0UMOt9E
# JM6oadJA1Nqnov2qPSB5rrkXlxI546YE7K+AG99yAgCjGMTkHvp+cKhFXBPTk8oZ
# lmSUuQJ1lE54qJOJoMDjQVkNQyzhhZGcF099+CDwqneP9/y3fyLYs4rLclGWLJpf
# wuGYXQC2732MM799TsX/DU5leSBsVnR55Nh4YeG580yqLBGg6yb0DIkPpaKIzO3+
# W4HcgQZ2EAZufv4ibMcPJNtu8xdo2zSPjsLPBy3mRrfLeridnlYzQ9QdGLYLAT9H
# LAZZ5yPuPnby2EbdHAKsOj4mEs+RUmXG6YtMXQB/43d3c8hgK28i7qOvR7oHxhBG
# /7DNO63KD9aN3GfHljG+PjCAfHrjm+Q1Tw5xHBYuDQ7pGDPdYNQ7f6iHpPq7RPPF
# UvECAwEAAaOCAUkwggFFMB0GA1UdDgQWBBSFcURpUhGRPtREiulBiO2DXBCI2zAf
# BgNVHSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQ
# hk5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQl
# MjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBe
# MFwGCCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2Nl
# cnRzL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAM
# BgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQE
# AwIHgDANBgkqhkiG9w0BAQsFAAOCAgEAdeC9ky/i/Dly8Zxkmpdod9JmexbARaKI
# mJFFTmNORfaZ8D01bnxAxlhKTTctjn2lB1iDqEP/f648DtIUtkqQdAczAJNoMs/d
# jRljqVm6QXTL660Q6YlmYv7i0uGRnUZ9z9g3HGJpZDT/r2kQF757/pqduyoCO/Zi
# fYRsgkG77TCI5G2KC6iu7Be1moZ/ay419cuUCS+JbxMt0JgPSkQY+enBL/5QL8w6
# u3koqkav6QsqsnPLs5kPEnilslrug41APb4vOELJi46jxgpx+HD8oPrfeUaVvu97
# J4XsNYglfsF7tkcTJ1oOxLA+Xi5CRy7M1CD3flwpQ/hU71dNxn6ww35PuOX5R/3i
# kWXNzFGbZ4SyYz8L9yqCg0nFuIlekmwkcnGD5KqFgax3+0rwwOxqx9lDrc9VmtZN
# u7HWYKRuv3PQqiiPAl+b4GmvgO6GB2+GQY+0vLvLIMcFiux4Fg0Qcjh9woibuCyf
# Id04kZEQK5h0adJWzX9YgCri/POiChPddr9MquebfIzMYwVO7qC7K2FSKCpM4frA
# JIJKRjqGS9ePnZcVTPdQWr82uJDg01JcM2/kqV7EqlcfJ7geqoVMu6aqYMMNauEj
# YQMRZxcbMYk5WqC++RjcT0etOZSdll3obRIu//mHyarx/r56nKago8kPYTWlc7jh
# B1+DMrqnI8IwggdxMIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqG
# SIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkg
# MjAxMDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEA5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4X
# YDP/XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTz
# xXb1hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7
# uhp7M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlw
# aQ3KNi1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedG
# bsoy1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXN
# xF803RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03
# dJQcNIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9
# ahhaYQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5
# UPkLiWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReT
# wDwV2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZ
# MBIGCSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8
# RjUpzxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAE
# VTBTMFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAww
# CgYIKwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQD
# AgGGMA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb
# 186aGMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29t
# L3BraS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoG
# CCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZI
# hvcNAQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9
# MTO1OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2Lpyp
# glYAA7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OO
# PcbzaN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8
# DJ6LGYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA
# 0j3mSj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1Rt
# nWN0SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjc
# ZxkoJLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq7
# 7EFmPWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJ
# C4822rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328
# y+l7vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYID
# UDCCAjgCAQEwgfmhgdGkgc4wgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo4OTAwLTA1RTAtRDk0NzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUA
# Suh2P2Vi5znDBELI5AwKAfyWVgiggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEG
# A1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWlj
# cm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFt
# cCBQQ0EgMjAxMDANBgkqhkiG9w0BAQsFAAIFAOuscZswIhgPMjAyNTA0MTgwNjM3
# MTVaGA8yMDI1MDQxOTA2MzcxNVowdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA66xx
# mwIBADAKAgEAAgILsQIB/zAHAgEAAgISSzAKAgUA663DGwIBADA2BgorBgEEAYRZ
# CgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0G
# CSqGSIb3DQEBCwUAA4IBAQCaM4WWDbX0Y9bhWYy8HNpLbzXnqcev4zEAm3OhxEmp
# j7DW/oaMak52ViiG5ViU/ZlP3ylgnJAUbLEzavwLWZs0tzjF9FwTfH30ZY4eDLIe
# 17iE81HIvTzX1R0yvBygpUp/XsQ9ZFZb/8pmuYtdOwCZS/oyzNpmXkLt9Pi+R4wb
# nGdcMjFhjzgcqiF1jlavqmujo4pC3eMwGr5xby+VHzyB+7tkxjKDvj/GAv4KFr67
# FFrYqhEBJYiZ30gqwjMUilJPnt2UZ2vlDBK+wUEhsdcvlSP1YerxYBc5dchf6pT9
# pBW81ap+YcuW+pxi1Tasazo4K36ARp0Uhl/zog+/FW5dMYIEDTCCBAkCAQEwgZMw
# fDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1Jl
# ZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMd
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAIOLMsofZUgdWMAAQAA
# Ag4wDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRAB
# BDAvBgkqhkiG9w0BCQQxIgQgaZJNdpaKH/U2e+LZCt7P1FVhS0mEG20iEbjEf1YH
# Iu4wgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCABdB1zJfDpgZCtuu5saGyk
# oocDnT9HlDV0DMqT808ShjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAACDizLKH2VIHVjAAEAAAIOMCIEIAD6QTqxcpYhS7sK7pVAQXfp
# pdcuaZcj1JoLHGRRS9KlMA0GCSqGSIb3DQEBCwUABIICAFbdQPm8xesg2/ZTGa/r
# MNp90rIspxZYLMevMXyPNLobliQtk9sDUExVKfY7N2B1H6q5HgALVmjDfiLUv2GG
# cHSHRL2+uu+J9sp3aP09t0tyMR0x7CwWpIffNsQt4IQliEr4JyR4NGrpP0VK/06Y
# lulPCKhmk6bBS4ko/k7nqQmfn+S6kw9Tp3/3dFLx4NTOAsXWOPBZSN3kYCkoG3eV
# 0P8WBTfxRZ+4w3WbmO9A8FO1wM7g3t4KggOWyIv7DqAcxPVure7QIPnfrXoytLLX
# 5JI7TRt4D2ei3XGDuQ8VGkkDERmgg/BGr6f97i5ykz/ZQLiUh1uPkMCYk7KIwF6L
# k0DkFrK1H3tkFKbMJRGnZ1g1gc4NSMNNgbrbtvlIsRyJFeqmLdd1j0kQo8Ithzwu
# JdeQ1Xkl9qqxGCSgtkSzgdFoSQQxSldkeUzv8nYL+tdktc3WhSoEP27BdmvAax9H
# umPYNDy1edxyecA1mymG+R7HDNkPBX8mzmYV+U77FIgvBsyBeDgAR1SJ4j/Tufj0
# OhkvxdmEgHdpu4F+rQi+JsrVx2FdmMPNxMtJ8/v3CB1ozE/oi81KA+WeMpvLqZR7
# EQ74OCnXB2Qa4C2G0I+JQfIhXdk7RxOFX6/e8UJVBpxgN+xZbvoM9Ovg639OGTJ1
# BjarS/HIDaVp6Cl3srxutX+B
# SIG # End signature block
